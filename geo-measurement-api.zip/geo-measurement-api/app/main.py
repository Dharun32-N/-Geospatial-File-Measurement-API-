from fastapi import FastAPI

from app.routes import router

app = FastAPI(
    title="Geospatial File Measurement API",
    description="Upload a KML or zipped Shapefile and get area/length measurements.",
    version="1.0.0",
)
app.include_router(router)


@app.get("/", tags=["health"])
def health_check():
    return {"status": "ok"}

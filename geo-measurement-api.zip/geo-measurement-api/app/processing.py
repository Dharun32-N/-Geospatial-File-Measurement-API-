"""Reading geospatial files, extracting features and calculating measurements."""
import math
import os
import tempfile
import zipfile
from functools import lru_cache
from pathlib import Path
from typing import Any, List

import geopandas as gpd
import pandas as pd
import pyogrio
import shapely
from pyproj import Transformer
from shapely.geometry import mapping
from shapely.ops import transform

AREA_TYPES = {"Polygon", "MultiPolygon"}
LENGTH_TYPES = {"LineString", "MultiLineString"}
NO_MEASUREMENT_TYPES = {"Point", "MultiPoint"}

MAX_UNCOMPRESSED_ZIP_BYTES = 200 * 1024 * 1024  # protects against zip bombs


class FileProcessingError(Exception):
    """Raised when an uploaded file cannot be read as geospatial data."""


# --------------------------------------------------------------------------
# 1. Reading files
# --------------------------------------------------------------------------
def read_geodataframe(filename: str, content: bytes) -> gpd.GeoDataFrame:
    """Read a .kml file or a .zip (containing a Shapefile) into a GeoDataFrame."""
    suffix = Path(filename).suffix.lower()
    if suffix not in (".kml", ".zip"):
        raise FileProcessingError(
            "Unsupported file type. Upload a .kml file or a .zip containing a Shapefile."
        )

    with tempfile.TemporaryDirectory() as tmp:
        try:
            if suffix == ".zip":
                gdf = _read_zipped_shapefile(content, tmp)
            else:
                gdf = _read_kml(content, tmp)
        except FileProcessingError:
            raise
        except Exception as exc:  # unreadable / corrupt data
            raise FileProcessingError(f"Could not read geospatial data: {exc}") from exc

    # Drop rows that have no usable geometry.
    gdf = gdf[gdf.geometry.notna() & ~gdf.geometry.is_empty].reset_index(drop=True)
    if gdf.empty:
        raise FileProcessingError("The file does not contain any features with geometry.")
    return gdf


def _read_kml(content: bytes, tmp: str) -> gpd.GeoDataFrame:
    path = os.path.join(tmp, "upload.kml")
    with open(path, "wb") as f:
        f.write(content)

    # A KML file can hold several layers (one per folder), so read all of them.
    layer_names = [row[0] for row in pyogrio.list_layers(path)]
    frames = [gpd.read_file(path, layer=name) for name in layer_names]
    frames = [frame for frame in frames if not frame.empty]
    if not frames:
        raise FileProcessingError("The KML file does not contain any features.")

    gdf = pd.concat(frames, ignore_index=True)
    gdf = gpd.GeoDataFrame(gdf, geometry="geometry")
    # KML always uses WGS84 (EPSG:4326) by specification.
    return gdf.set_crs(epsg=4326, allow_override=True)


def _read_zipped_shapefile(content: bytes, tmp: str) -> gpd.GeoDataFrame:
    zip_path = os.path.join(tmp, "upload.zip")
    extract_dir = os.path.join(tmp, "extracted")
    with open(zip_path, "wb") as f:
        f.write(content)

    try:
        with zipfile.ZipFile(zip_path) as zf:
            if sum(info.file_size for info in zf.infolist()) > MAX_UNCOMPRESSED_ZIP_BYTES:
                raise FileProcessingError("The zip archive is too large once extracted.")
            zf.extractall(extract_dir)
    except zipfile.BadZipFile as exc:
        raise FileProcessingError("The uploaded file is not a valid zip archive.") from exc

    shp_files = sorted(Path(extract_dir).rglob("*.shp"))
    if not shp_files:
        raise FileProcessingError("No .shp file was found inside the zip archive.")

    gdf = gpd.read_file(shp_files[0])
    if gdf.crs is None:
        raise FileProcessingError(
            "The Shapefile has no CRS (the .prj file is missing), so measurements "
            "cannot be calculated reliably."
        )
    return gdf


# --------------------------------------------------------------------------
# 2. Feature extraction
# --------------------------------------------------------------------------
def crs_label(gdf: gpd.GeoDataFrame) -> str:
    epsg = gdf.crs.to_epsg()
    return f"EPSG:{epsg}" if epsg else gdf.crs.to_string()


def build_features(gdf: gpd.GeoDataFrame) -> List[dict]:
    """Return one dictionary per feature: id, geometry type, geometry, CRS, properties."""
    label = crs_label(gdf)
    geometry_column = gdf.geometry.name
    features = []
    for index, row in gdf.iterrows():
        geom = row[geometry_column]
        properties = {
            str(key): _to_json_safe(value)
            for key, value in row.items()
            if key != geometry_column
        }
        features.append(
            {
                "id": int(index),
                "geometry_type": geom.geom_type,
                "geometry": mapping(geom),
                "crs": label,
                "properties": properties,
            }
        )
    return features


def _to_json_safe(value: Any) -> Any:
    """Convert pandas/numpy values into plain JSON-friendly Python values."""
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if hasattr(value, "item") and not isinstance(value, (str, bytes)):
        try:
            value = value.item()
        except (ValueError, AttributeError):
            pass
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


# --------------------------------------------------------------------------
# 3. Measurements
# --------------------------------------------------------------------------
def calculate_measurements(gdf: gpd.GeoDataFrame) -> List[dict]:
    """Measure every feature. Geometries are converted to WGS84 first, then each
    one is projected to its own UTM zone so distances/areas are in metres."""
    wgs84 = gdf.to_crs(epsg=4326)
    results = []
    for index, geom in wgs84.geometry.items():
        result = measure_geometry(geom)
        result["feature_id"] = int(index)
        result["geometry_type"] = geom.geom_type
        results.append(result)
    return results


def measure_geometry(geom_wgs84) -> dict:
    geom_type = geom_wgs84.geom_type

    if geom_type in NO_MEASUREMENT_TYPES:
        return {"status": "NOT_REQUIRED", "message": "No measurement is required for points."}

    if geom_type not in AREA_TYPES | LENGTH_TYPES:
        return {
            "status": "UNSUPPORTED",
            "message": f"Measurement is not supported for geometry type '{geom_type}'.",
        }

    geom_2d = shapely.force_2d(geom_wgs84)  # ignore altitude (Z) values
    epsg = utm_epsg_for(geom_2d)
    projected = transform(_transformer_to_utm(epsg).transform, geom_2d)

    result = {"status": "MEASURED", "projected_crs": f"EPSG:{epsg}"}
    if geom_type in AREA_TYPES:
        area = projected.area
        result["area_sq_m"] = round(area, 3)
        result["area_hectares"] = round(area / 10_000, 5)
    else:
        result["length_m"] = round(projected.length, 3)
    return result


def utm_epsg_for(geom_wgs84) -> int:
    """Pick the UTM zone (WGS84) that contains the geometry's centroid.
    Northern hemisphere = EPSG:326xx, southern hemisphere = EPSG:327xx."""
    centroid = geom_wgs84.centroid
    zone = min(int((centroid.x + 180) // 6) + 1, 60)
    return (32600 if centroid.y >= 0 else 32700) + zone


@lru_cache(maxsize=128)
def _transformer_to_utm(epsg: int) -> Transformer:
    return Transformer.from_crs("EPSG:4326", f"EPSG:{epsg}", always_xy=True)

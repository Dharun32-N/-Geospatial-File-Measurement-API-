"""API endpoints."""
from typing import List

from fastapi import APIRouter, File, HTTPException, UploadFile

from app.processing import (
    FileProcessingError,
    build_features,
    calculate_measurements,
    crs_label,
    read_geodataframe,
)
from app.schemas import Feature, FileInfo, MeasurementsResponse
from app.storage import StoredFile, store

router = APIRouter(prefix="/api/files", tags=["files"])

MAX_UPLOAD_BYTES = 25 * 1024 * 1024  # 25 MB


def _to_info(stored: StoredFile) -> FileInfo:
    return FileInfo(
        id=stored.id,
        filename=stored.filename,
        feature_count=len(stored.features),
        crs=stored.crs,
        status=stored.status,
        created_at=stored.created_at,
    )


def _get_or_404(file_id: str) -> StoredFile:
    stored = store.get(file_id)
    if stored is None:
        raise HTTPException(status_code=404, detail="File not found.")
    return stored


@router.post("/", response_model=FileInfo, status_code=201)
def upload_file(file: UploadFile = File(...)):
    """Upload a .kml file or a .zip containing a Shapefile and process it."""
    content = file.file.read(MAX_UPLOAD_BYTES + 1)
    if not content:
        raise HTTPException(status_code=400, detail="The uploaded file is empty.")
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File is too large (limit is 25 MB).")

    filename = file.filename or "upload"
    try:
        gdf = read_geodataframe(filename, content)
        features = build_features(gdf)
        measurements = calculate_measurements(gdf)
    except FileProcessingError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    stored = store.add(filename, crs_label(gdf), features, measurements)
    return _to_info(stored)


@router.get("/{file_id}/", response_model=FileInfo)
def get_file(file_id: str):
    """Return basic information about an uploaded file."""
    return _to_info(_get_or_404(file_id))


@router.get("/{file_id}/features/", response_model=List[Feature])
def get_features(file_id: str):
    """Return every feature (id, geometry type, geometry, CRS, properties)."""
    return _get_or_404(file_id).features


@router.get("/{file_id}/measurements/", response_model=MeasurementsResponse)
def get_measurements(file_id: str):
    """Return area/length measurements for every feature."""
    stored = _get_or_404(file_id)
    return MeasurementsResponse(
        file_id=stored.id,
        source_crs=stored.crs,
        feature_count=len(stored.features),
        measurements=stored.measurements,
    )

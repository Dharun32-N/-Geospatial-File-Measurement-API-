"""Pydantic models that define the shape of API responses."""
from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class FileInfo(BaseModel):
    id: str
    filename: str
    feature_count: int
    crs: str
    status: str
    created_at: datetime


class Feature(BaseModel):
    id: int
    geometry_type: str
    geometry: Dict[str, Any]
    crs: str
    properties: Dict[str, Any]


class Measurement(BaseModel):
    feature_id: int
    geometry_type: str
    status: str  # MEASURED | NOT_REQUIRED | UNSUPPORTED
    area_sq_m: Optional[float] = None
    area_hectares: Optional[float] = None
    length_m: Optional[float] = None
    projected_crs: Optional[str] = None
    message: Optional[str] = None


class MeasurementsResponse(BaseModel):
    file_id: str
    source_crs: str
    feature_count: int
    measurements: List[Measurement]

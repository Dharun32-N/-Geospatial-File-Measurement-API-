"""In-memory storage for processed files.

Kept deliberately simple for this assignment. The FileStore class hides the
storage details, so it can be swapped for SQLite/PostgreSQL later without
touching the API routes.
"""
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List, Optional


@dataclass
class StoredFile:
    id: str
    filename: str
    crs: str
    status: str
    created_at: datetime
    features: List[dict]
    measurements: List[dict]


class FileStore:
    def __init__(self) -> None:
        self._files: Dict[str, StoredFile] = {}
        self._lock = threading.Lock()

    def add(
        self,
        filename: str,
        crs: str,
        features: List[dict],
        measurements: List[dict],
    ) -> StoredFile:
        stored = StoredFile(
            id=uuid.uuid4().hex[:12],
            filename=filename,
            crs=crs,
            status="COMPLETED",
            created_at=datetime.now(timezone.utc),
            features=features,
            measurements=measurements,
        )
        with self._lock:
            self._files[stored.id] = stored
        return stored

    def get(self, file_id: str) -> Optional[StoredFile]:
        with self._lock:
            return self._files.get(file_id)


store = FileStore()
